function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6gXe3wUWdlG":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

